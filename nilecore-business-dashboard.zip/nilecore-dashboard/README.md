# NileCore Business Dashboard

This is a ready-to-deploy web app for Angels Loft (or any business you rebrand it for).

## What this is
A React project. Not a single file you double-click — it needs to be "built" and hosted.
The easiest way to do that needs no coding knowledge, just following steps below.

## Important: how data storage works right now
This version saves data using your browser's own storage (localStorage). That means:
- It works fully standalone — no Claude, no internet needed after the page loads.
- BUT each device/browser keeps its own separate copy of the data. If your attendant
  uses it on their phone and you use it on yours, you will NOT see the same numbers.
- This is fine for a single-device pilot or testing. For a real shared dashboard where
  everyone sees the same live data, you eventually need a proper backend (a real
  database) — that's a bigger step, talk to a developer when you're ready for it.

## Easiest way to publish this (free, ~10 minutes, no coding)

**Option A — Vercel (recommended)**
1. Go to vercel.com and sign up (free) with your email or GitHub.
2. Click "Add New Project" → "Import" (or drag-and-drop this whole folder if offered).
3. If it asks for a GitHub repo: upload this folder to a new GitHub repository first
   (GitHub.com → New Repository → upload files → drag this whole folder in), then
   connect that repo to Vercel.
4. Vercel auto-detects it's a Vite project. Click Deploy.
5. In a minute or two, you get a live link like `angelsloft.vercel.app` — share that
   link with anyone, they can open it on any phone or computer.

**Option B — Netlify**
Same idea as Vercel: netlify.com → sign up free → "Add new site" → drag and drop
this folder (or connect via GitHub) → it builds and gives you a live link.

## Want your own domain name?
Once it's live on Vercel/Netlify, you can connect a custom domain like
`dashboard.angelsloft.com` or `pos.nilecore.com`. Buy the domain (roughly $10-15/year)
from any registrar (Namecheap, GoDaddy, etc), then follow Vercel/Netlify's
"Add Custom Domain" instructions — they'll tell you exactly what settings to add.

## If you'd rather hand this to a developer
Give them this whole folder plus this README. Everything they need to run it locally
is: install Node.js, run `npm install`, then `npm run dev` to test or `npm run build`
to produce the production files. The one thing to flag to them explicitly: the
storage layer (top of src/App.jsx, the loadStorage/saveStorage functions) currently
uses localStorage and needs to be swapped for a real backend if multi-device shared
data is required.
